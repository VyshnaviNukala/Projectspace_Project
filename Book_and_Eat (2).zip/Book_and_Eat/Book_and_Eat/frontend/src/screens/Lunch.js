import React, { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.css'
import { Modal ,Button , Form} from 'react-bootstrap'
import lunch from '../Data1'
import Nev from '../Components/Navbar'; 
import {Link } from 'react-router-dom';
import Footer from '../Components/Footer.js';
//import Breakfastdiv from '../components/Breakfastdiv'
export default function Lunch() {
  // const [show, setShow] = useState(false);

  // const handleClose = () => setShow(false);
  
  const [quantity, setquantity] = useState(1);
  const [product, setProduct] = useState([]);
  const [selecteditem, setSelecteditem] = useState([
    {
    'name':'',
    'image':'',
    'description':''
    }]
    );

  useEffect(() => {
    setProduct(lunch)
  }, []);

  // const handleShow = (products) => {
  //   console.log(products)
  //   let newitem = [{
  //     'name':products.name,
  //     'image':products.image,
  //     'description':products.description
  //     }]
  //     // console.log(newitem)
  //   setSelecteditem([...newitem]);
  //   console.log(selecteditem)
  //   setShow(true);
  // }

  const [show, setShow] = useState(false);

  const handleClosee = () => setShow(false);
  const handleShoww= () => setShow(true);

  const changeItems = (qty, pro) => {
    let price = pro.default_price;
    let updated_price = price * qty;
    pro.prices = updated_price;
    console.log(pro);
    setProduct([...product, pro]);
  }

  return (
    <div >
      <Nev/>
      <br/>
      <br/>
      <br/>
      <br/>
      <h1>Lunch</h1>
      <div className='row' id="c2">
        {
          
          <div className='col-md-12 m-3 shadow-lg p-3  bg-white rounded ' id="c1" >{
           
            product.map((item, i) => {

              return (

                <div className='col-md-3 m-3 shadow-lg p-3  bg-white rounded' id="dd">
                  <div >
                    <h3>{item.name}</h3>
                    <img src={item.image} width="200px" height="200px" id="c3"/>
                  
                  </div>
                  
                  <div className="flex-container">
                    <div className='w-100'>
                      <div className='m-1 w-100'>
                        <h4>Price :<br></br> {item.prices * quantity}</h4>
                      </div>

                    </div>
                    
                    <div className='w-100 m-1'>

                      <h4>Quantity:</h4>
                      <select className="form-control" onChange={(e) => { changeItems(e.target.value, item) }} >
                        {
                          [...Array(10).keys()].map((x, i) => {
                            // console.log(i)
                            // <h2>haiii</h2>
                            return <option value={i + 1}>{i + 1}</option>
                          })
                        }
                      </select>
                      
                    </div>
                  </div>
                  <div className="flex-container">
                    <div className='m-1 w-100'><br></br>
                      {/* <button className="btn1">Order Now </button> */}
                      <Button variant="primary" className="btn1 "onClick={handleShoww}>
        Order Now
      </Button>

      <Modal show={show} onHide={handleClosee}>
        <Modal.Header closeButton>
          <Modal.Title>Enter Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Form >
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Enter Name</Form.Label>
        <Form.Control type="email" placeholder="Enter your name" required/>
       
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Enter Number</Form.Label>
        <Form.Control type="text" placeholder="Enter your Password" required/>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Enter User Id</Form.Label>
        <Form.Control type="text" placeholder="Enter your User Id" required/>
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicCheckbox">
        <Form.Check type="checkbox" label="Check me out" />
      </Form.Group>
      {/* <Button variant="warning" type="submit">
        Order Now
      </Button> */}
      <Link to='/home'><Button variant="warning" type="submit">
        Confirm
      </Button></Link>
    </Form>
        </Modal.Body>
         
      </Modal>
                    </div>
                    
                  </div>
                    
                </div>
                
              )
                        
            }
            
            )


          }
          </div>
        }
      </div>
      
          <Footer/>
    </div>
  )
}
