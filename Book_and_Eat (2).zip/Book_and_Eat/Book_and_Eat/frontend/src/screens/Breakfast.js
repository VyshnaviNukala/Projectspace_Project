import React, { useState, useEffect } from 'react'
import 'bootstrap/dist/css/bootstrap.css'
import {Link } from 'react-router-dom';
import { Modal ,Card} from 'react-bootstrap';
import { Button ,Form} from 'react-bootstrap';
//import Form from './Components/Form'
import breakfast from '../Data'
import Nev from '../Components/Navbar'; 
import Footer from '../Components/Footer.js';
import axios from 'axios';
// import SearchForm from '../components/Meal'
// import Breakfastdiv from '../components/Breakfastdiv'
export default function Breakfast() {
  // const [show, setShow] = useState(false);

  // const handleClose = () => setShow(false);
  
  const [quantity, setquantity] = useState(1);
  const [product, setProduct] = useState([]);
  const [searchInput, setSearchInput] = useState('');
  const [filteredResults, setFilteredResults] = useState([]);
  const [order,setOrder] = useState({
    name:"",
    number:"",
    userid:"",
 
 })
  const [selecteditem, setSelecteditem] = useState([
    {
      'id':'',
      'name':'',
      'qty':1,
      'default_price':'',
      'total':'',
    }]
    );
    const searchItems = (searchValue) => {
      // console.log(searchValue)
      //setSearchInput(searchValue)
      // const filteredData = product.filter((item) => {
      //     return Object.values(item.name).join('').toLowerCase().includes(searchInput.toLowerCase())
      // })
      // const filteredData = product.filter( item => searchValue.includes( item.name ) );
      // const [show, setShow] = useState(false);

      // const handleClose = () => setShow(false);
      // const handleShow = () => setShow(true);
      
      const filteredData = product.filter(function(el){
        return el.name === "Joe"
       });
      console.log(filteredData)
      setFilteredResults(filteredData)
    }
   
    useEffect(() => {
    setProduct(breakfast)
  }, []);

  const handleShoww = (e, products) => {
    console.log("handle show")
    console.log(products)
    let newitem = [{
      'id':products._id,
      'name':products.name,
      'qty':products.qty,
      'default_price':products.default_price,
      'total':products.prices,
      }]
      // console.log(newitem)
    setSelecteditem([...newitem]);
    console.log(selecteditem);
    setShow(true);
  }

  const [show, setShow] = useState(false);

  const handleClosee = () => setShow(false);
  // const handleShoww= () => setShow(true);

  const changeItems = (qty, pro) => {
    let price = pro.default_price;
    let updated_price = price * qty;
    pro.qty = qty;
    pro.prices = updated_price;
    console.log(pro);
    setProduct([...product, pro]);
  }

  const handleChange = (e) => {
    setOrder((prevState)=>({
        ...prevState,
        [e.target.name]:e.target.value
    }))
    console.log(e.target.value)
}

  

  const orderSubmit = (e) =>{
    e.preventDefault()
    console.log(selecteditem)
    order.itemid = selecteditem[0].id;
    order.itemname = selecteditem[0].name;
    order.itemqty = selecteditem[0].qty;
    order.item_price = selecteditem[0].default_price;
    order.item_total_cost = selecteditem[0].total;
    axios.post('http://127.0.0.1:5000/postorderdata',{order})
    .then((res)=>{
     console.log(res.data.books)
 
   })
   }

  return (
    
    
    <div  id="hai">
      <Nev/>
      <br/>
      <br/>
      <br/>
      <br/>
      <h2 style={{color:'black'}}>Break Fast</h2>
      {/*  */}
      <div className='row' id="c2">
        {




      (    <div className='col-md-12 m-3 shadow-lg p-3 bg-white rounded ' id="c1" >{
           
            product.map((item, i) => {

              return (

                <div className='col-md-3 m-3 shadow-lg  p-3  bg-white rounded' id="dd" >
                  <div >
                    <h3>{item.name}</h3>
                    <img src={item.image} width="200px" height="200px" id="c3"/>
                  
                  </div>
                  
                  <div className="flex-container">
                    <div className='w-100'>
                      <div className='m-1 w-100'>
                        <h4>Price :<br></br> {item.prices * quantity}</h4>
                      </div>

                    </div>
                    
                    <div className='w-100 m-1'>

                      <h4>Quantity:</h4>
                      <select className="form-control" onChange={(e) => { changeItems(e.target.value, item) }} >
                        {
                          [...Array(10).keys()].map((x, i) => {
                            // console.log(i)
                            // <h2>haiii</h2>
                            return <option value={i + 1}>{i + 1}</option>
                          })
                        }
                      </select>
                      
                    </div>
                  </div>
                  <div className="flex-container">
                    <div className='m-1 w-100'><br></br>
                      {/* <button className="btn1 " >Order Now</button></div> */}

                      
      <Button variant="primary" className="btn1 " onClick={(e) => handleShoww(e,item)}>
        Order Now
      </Button>

      <Modal show={show} onHide={handleClosee}>
        <Modal.Header closeButton>
          <Modal.Title>Enter Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Form  onSubmit={orderSubmit}>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Enter Name </Form.Label>
        <Form.Control type="text" name="name" placeholder="Enter your name" required onChange={handleChange} />
       
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Enter Number</Form.Label>
        <Form.Control type="text" name="number" placeholder="Enter your Password" required onChange={handleChange}/>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Enter User Id</Form.Label>
        <Form.Control type="text" name="userid" placeholder="Enter your User Id" required onChange={handleChange}/>
      </Form.Group>
      {/* <Form.Group className="mb-3" controlId="formBasicCheckbox">
        <Form.Check type="checkbox" label="Check me out" />
      </Form.Group> */}
      {/* <Button variant="warning" type="submit">
        Confirm
      </Button> */}
      <Link to='/home'><Button variant="warning" type="submit" onClick={() => alert('Ordered Successfully')}>
        Confirm
      </Button></Link>
    </Form>
        </Modal.Body>
         
      </Modal>
    </div>
                  </div>
                    
                </div>
                
              )
                        
            }
            
            )


          }
          </div>
  )
        }
      </div>
      {
        show ?
        <>
          
      

      
    </>
      :''
      }
      {
       show ? 
      
      <>
            
            </>
            
          : ''
          }
          <Footer/>
    </div>
    
  )
}