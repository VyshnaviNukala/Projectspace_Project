import React from 'react'; 
 import './App.css';

import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import Home from './Components/Home';
import LoginPage from './Components/Login';
import SignUp from './Components/signUp';
import Breakfast from './screens/Breakfast';
import Lunch from './screens/Lunch';
import Snacks from './screens/Snacks';
//import Details from './Components/Details';
import Dashboard from './Components/Dashboard';


import { BrowserRouter,Routes,Route } from 'react-router-dom';



function App() {
  return (
    <div className="App">
     
      <BrowserRouter>
     {/* <LoginPage/> */}
      <Routes>
      
         <Route path='/home' element={<Home/>}/>
        <Route path='/' element={<LoginPage/>}/>
         <Route path='/signup' element={<SignUp/>}/> 
        <Route path='/breakfast' element={<Breakfast/>}/>
        <Route path='/lunch' element={<Lunch/>}/>
        <Route path='/snacks' element={<Snacks/>}/>
        <Route path='/dashboard' element={<Dashboard/>}/>

          </Routes>
          </BrowserRouter>
          
          
         
    </div>
  );
}

export default App;
