import React,{useState,useEffect } from 'react';
import '../App.css';
import {useNavigate} from "react-router-dom"
//import React,{useState,useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
//import {Link} from 'react-router-dom';
// import axios from 'axios';
function SignUp() {
 
  const [send,setSend] = useState({
   em:"",
   pass:"",
   con:"",

})

const handleChange = (e) => {
    setSend((prevState)=>({
        ...prevState,
        [e.target.name]:e.target.value
    }))
    console.log(e.target.value)
}

const postSubmit = (e) =>{
   e.preventDefault()
   axios.post('http://127.0.0.1:5000/postdata',{send})
   .then((res)=>{
    console.log(res.data.books)

  })
  }
  const navigate = useNavigate();

    return ( 
        <>
         {/* <div>
          <ul>
            <li><Link to={'/'}>Home</Link>
          </li>
          <li><Link to={'/SignUp'}>SignUp Page</Link></li>
          </ul>
        </div> */}
         {/* <button onClick={()=>navigate(-2)}>Go Back Home</button> */}
        <div className='haii' >
      <div className='wrapper  d-flex align-items-center justify-content-center w-140' >
        <div className="login" >
          <h2 className='mb-3'>Register</h2>
          <form className="needs-validation"   onSubmit={postSubmit} >
                <div className="form-group was-validated mb-2">
                    <label htmlFor="email" style={{color:'white'}}  className="form-label">Email Address</label>
                    <input type="email" className="form-control" name="em"  onChange={handleChange} required placeholder='Enter Your Email' style={{background:'transparent'}}></input>
                    
                </div>
                <div className="form-group  was-validated mb-2">
                    <label htmlFor="password" style={{color:'white'}}   className="form-label">Password</label>
                    <input type="password" className="form-control" name="pass" onChange={handleChange}  required placeholder='Enter Your Password' style={{background:'transparent'}}></input>
                    
                </div>
                <div className="form-group  was-validated mb-2"> 
                    <label htmlFor="password" style={{color:'white'}}  className="form-label">Confirm Password</label>
                    <input type="password" className="form-control" name="con" onChange={handleChange}  required placeholder='Enter Confirm Password' style={{background:'transparent'}}></input>
                    
                </div>
                
                
                
                <button type='submit' className='btn btn-success w-100 mt-2' onClick={()=>navigate('/')}>Sign Up</button>
            
          </form>
          
        </div>
          
         
    </div>
   
    </div >
    </>  
    );
  }
  
  export default SignUp;