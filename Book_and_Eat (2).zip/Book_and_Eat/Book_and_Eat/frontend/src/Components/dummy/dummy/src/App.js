import React from 'react';
import Dashboard from './Components/Dashboard';
import Dashboard1 from './Components/Dashboard copy';
import Sidebar from './Components/Sidebar';
import { BrowserRouter,Route,Routes } from 'react-router-dom';
// import Home from './Components/Home';
// import LoginPage from './Components/Login';
// import SignUp from './Components/signUp';
// import Details from './Components/Details';
// import Breakfast from './screens/Breakfast';
// import Lunch from './screens/Lunch';
// import Snacks from './screens/Snacks';
function App(){
 
        return (
            <div>
               
                <div class="container-fluid" id="main">
                 <div class="row row-offcanvas row-offcanvas-left">
                 <BrowserRouter>
                    <Sidebar/> 

                    <Routes>
   
         <Route path='/' element={<Dashboard/>}/>
         <Route path='/dash' element={<Dashboard1/>}/>
         {/* <Route path='/details' element={<Details/>}/>
        <Route path='/login' element={<LoginPage/>}/>
        <Route path='/signup' element={<SignUp/>}/>
        <Route path='/breakfast' element={<Breakfast/>}/>
        <Route path='/lunch' element={<Lunch/>}/>
        <Route path='/snacks' element={<Snacks/>}/>
        <Route path='/Dashboard' element={<Dashboard/>}/>
        <Route path='/Sidebar' element={<Sidebar/>}/> */}
        </Routes>
          </BrowserRouter> 
                 {/* <Sidebar/> 
                  <Dashboard/> */}
                 
             </div>
            </div>  
        </div>  
        );
    }
  
export default App