import React, { useState } from "react";
import axios from 'axios';

function Details (){
  // let [data, setData ] = useState([]); 
  // useEffect(())

  const[values,setValues]=useState({
    fname:"",
   lname:""
  })
const handleChange=(e)=>
{
  setValues({
    ...values,
    [e.target.name]:e.target.values
  })

}

const handleSubmit1= (e) =>{
  e.preventDefault();
  axios.post('http://127.0.0.1:5000/confirmuser',{values})
   .then((res)=>{
    console.log(res.data)

  })
}

    return(
     <div>
      <form onSubmit={handleSubmit1}>
        <label>Fname</label>
        <input type="text" name="fname" onChange={handleChange}/>
        <br/>
        <label>Lname</label>
        <input type="text" name="lname" onChange={handleChange}/>
        <button type="submit" className="btn btn-info btn-lg" > submit</button>
        
        </form>  
   </div>   
    )
}
export default Details