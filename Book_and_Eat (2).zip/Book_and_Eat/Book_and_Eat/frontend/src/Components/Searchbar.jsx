import React from 'react';
import { useState } from 'react';
import { FaSearch } from 'react-icons/fa';
import axios from 'axios';

const Searchbar=()=> {

    const [input,setInput]=useState("");

    const fetchData = (value)=>{
        fetch('http://127.0.0.1:8000/getBreakfast').then((response => response.json)).then((json) =>{
            console.log(json);
            
            const results =json.filter((user) => {
                return user && user.name && user.toLowerCase().includes(value);
            });
            console.log(results);
        });
    }
    const handleChange =(value) => {
        setInput(value)
        fetchData(value)
    }
    return(
        
        <center><div className='input-wrapper col-md-3'>

<FaSearch id='search-icon'/>
 <input placeholder='Type to search' value={input.name} onChange={(e)=> handleChange(e.target.value)}/>

        </div></center>
    )
  
}
export default Searchbar